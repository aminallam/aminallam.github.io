// To download 64-bits gcc on windows:
// Download CodeBlocks then use the gcc that comes with CodeBlocks. It may exist in "C:\Program Files\CodeBlocks\MinGW\bin\"

// To compile this assembly program on windows:
// "C:\Program Files\CodeBlocks\MinGW\bin\gcc" -O3 -o funmainc64.exe funmainc64.c fun64.s
// After running the program, enter a positive integer (n<=100) and then enter n integers then press enter

// ------------------------------------------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>

int SumIntegers(int*, int);

int main()
{
    int i, n=7;
    int* olda=malloc(n*sizeof(int)+3*sizeof(int)+15*sizeof(int));

    //int* a=(int*)((((int)olda)+15)&(~15));
    int* a=(int*)((((long long)olda)+15)&(~15));
    
    //printf("%d %d\n", (long long)olda, (long long)a); fflush(stdout);
    
    for(i=0;i<n;i++) a[i]=i+1;
    
    int x=SumIntegers(a, n);
    printf("Sum=%d\n", x); fflush(stdout);
    
    free(olda);
    return 0;
}

// ------------------------------------------------------------------------------------------------------
